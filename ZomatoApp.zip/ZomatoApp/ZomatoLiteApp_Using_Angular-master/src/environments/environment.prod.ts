export const environment = {
  production: true,
  firebaseAPIKey:'AIzaSyBQiGayXn-GaYaXx-rReGpUYPMNAXUsOnI'
};
